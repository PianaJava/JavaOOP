package oggetti;

public class JavaOOP {

	public static void main(String[] args) {
		//Conformita' di tipo
		
		Figure[] disegno = new Figure[1000];
		
		disegno[0] = new Quadrato(30,10,50);
		disegno[1] = new Quadrato(30,10,50);
		disegno[2] = new Cerchio(100,100,70);
		disegno[3] = new Rettangolo(new Punto(10,20),120,100);
		disegno[4] = new Quadrato(30,10,50);
		int numeroFigure =5;
		double totPerimetri=0;
		disegno[0].perimetro();
		
		for(int i=0;i<numeroFigure;i++) {
			totPerimetri+=disegno[i].perimetro();
		}
		
		System.out.println(totPerimetri );

	}

}
