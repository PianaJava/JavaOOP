package oggetti;

public class Quadrato extends Rettangolo {
	public Quadrato(int x1, int y1, int lato) {
		super (x1,y1,lato,lato);
	}
	
	public double perimetro()
	{return 4*base;}

}
