package provaOCA;

public class Order {

	static String result ="";
	{result += "c";}
	static 
	{result += "u";}
	{result += "r";}
}
