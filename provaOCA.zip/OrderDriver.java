package provaOCA;

public class OrderDriver {

	public static void main(String[] args) {
		
		System.out.print(Order.result + " ");
		System.out.print(Order.result + " ");
		new Order();
		new Order();
		//System.out.print(Order.result + "");
	}
	
}
